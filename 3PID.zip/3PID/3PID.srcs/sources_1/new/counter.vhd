----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/17/2025 03:17:36 PM
-- Design Name: 
-- Module Name: counter - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity counter is
  generic(N : integer := 24);
  port ( 
    clk, en, res : in std_logic;
    preset : in unsigned(N-1 downto 0);
    mode : in  std_logic; -- 0 = down/reset 1 = up/down
    q : out unsigned(N-1 downto 0)
  );
end counter;

architecture Behavioral of counter is

  --signal cnt : unsigned(N-1 downto 0) := (others => '0');
  signal cnt : unsigned(N-1 downto 0) := to_unsigned(0,N);
  signal actual_mode : std_logic := '0'; -- 0 = down/reset 1 = up/down, default = 0

begin

  -- Output definition
  q <= cnt;
  
  -- Counter definition
  cntProc: process(clk,res)
    variable dir : std_logic := '0'; -- counting direction: 0 = up, 1 = down 
  begin
    if res = '1' then
      cnt <= (others => '0');
      dir := '0';
    elsif rising_edge(clk) then
      cnt <= cnt;
      -- changing mode only when cnt = 0 to prevent glitches
      if cnt = 0 then
        actual_mode <= mode;
        dir := '0';
      end if;
      
      if en = '1' then
        -- counter only down and reset to max
        if actual_mode = '0' then
          if cnt = preset then
            cnt <= (others => '0');   
          else
            cnt <= cnt + 1;       
          end if;     
        else
          if cnt = preset then
            dir := '1';
          elsif cnt = 0 then
            dir := '0';
          end if;
          if dir = '0' then
            cnt <= cnt + 1;
          else
            cnt <= cnt - 1;
          end if;
        end if;
      end if;
    end if;
  end process;

end Behavioral;
