----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/20/2026 08:50:26 PM
-- Design Name: 
-- Module Name: source_selector - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;


entity source_selector is
    Port (

        control_axi : in std_logic_vector(31 downto 0);

        -- FSM outputs
        en1_fsm   : in std_logic;
        en2_fsm   : in std_logic;
        en3_fsm   : in std_logic;
        
        res1_fsm  : in std_logic;
        res2_fsm  : in std_logic;
        res3_fsm  : in std_logic;

        mode1_fsm : in std_logic;
        mode2_fsm : in std_logic;
        mode3_fsm : in std_logic;

        p1_fsm    : in std_logic;
        i1_fsm    : in std_logic;
        d1_fsm    : in std_logic;

        p2_fsm    : in std_logic;
        i2_fsm    : in std_logic;
        d2_fsm    : in std_logic;

        p3_fsm    : in std_logic;
        i3_fsm    : in std_logic;
        d3_fsm    : in std_logic;
        
        -- outputs selected
        en1_o   : out std_logic;
        en2_o   : out std_logic;
        en3_o   : out std_logic;

        mode1_o : out std_logic;
        mode2_o : out std_logic;
        mode3_o : out std_logic;

        p1_o    : out std_logic;
        i1_o    : out std_logic;
        d1_o    : out std_logic;

        p2_o    : out std_logic;
        i2_o    : out std_logic;
        d2_o    : out std_logic;

        p3_o    : out std_logic;
        i3_o    : out std_logic;
        d3_o    : out std_logic;

        res1_o  : out std_logic;
        res2_o  : out std_logic;
        res3_o  : out std_logic
    );
end source_selector;

architecture Behavioral of source_selector is

    signal source_sel : std_logic;

begin          
    
    -- if source_sel = '1' the arm has the control, otherwise the fsm (the board)
    source_sel <= control_axi(31);

    en1_o <= control_axi(0) when source_sel='1' else en1_fsm;
    en2_o <= control_axi(1) when source_sel='1' else en2_fsm;
    en3_o <= control_axi(2) when source_sel='1' else en3_fsm;

    mode1_o <= control_axi(3) when source_sel='1' else mode1_fsm;
    mode2_o <= control_axi(4) when source_sel='1' else mode2_fsm;
    mode3_o <= control_axi(5) when source_sel='1' else mode3_fsm;

    p1_o <= control_axi(6) when source_sel='1' else p1_fsm;
    i1_o <= control_axi(7) when source_sel='1' else i1_fsm;
    d1_o <= control_axi(8) when source_sel='1' else d1_fsm;

    p2_o <= control_axi(9)  when source_sel='1' else p2_fsm;
    i2_o <= control_axi(10) when source_sel='1' else i2_fsm;
    d2_o <= control_axi(11) when source_sel='1' else d2_fsm;

    p3_o <= control_axi(12) when source_sel='1' else p3_fsm;
    i3_o <= control_axi(13) when source_sel='1' else i3_fsm;
    d3_o <= control_axi(14) when source_sel='1' else d3_fsm;

    res1_o <= control_axi(15) when source_sel='1' else res1_fsm;
    res2_o <= control_axi(16) when source_sel='1' else res2_fsm;
    res3_o <= control_axi(17) when source_sel='1' else res3_fsm;

end Behavioral;
