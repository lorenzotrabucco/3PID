----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/20/2026 05:12:27 PM
-- Design Name: 
-- Module Name: demux - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity adc_demux is
    port (
        clk : in std_logic;
        
        sample_pulse1 : out std_logic;
        sample_pulse2 : out std_logic;
        sample_pulse3 : out std_logic;

        m_axis_tdata  : in std_logic_vector(15 downto 0);
        m_axis_tid    : in std_logic_vector(4 downto 0);
        m_axis_tvalid : in std_logic;

        adc1 : out std_logic_vector(31 downto 0);
        adc2 : out std_logic_vector(31 downto 0);
        adc3 : out std_logic_vector(31 downto 0)
    );
end adc_demux;

architecture Behavioral of adc_demux is
begin
    process(clk)
    begin
    if rising_edge(clk) then
        
        sample_pulse1 <= '0';
        sample_pulse2 <= '0';
        sample_pulse3 <= '0';
        
        if m_axis_tvalid = '1' then -- 1 clock impulse

            case m_axis_tid is
                -- m_axis_tdata must be sliced beacuse the xadc works ai 12 bits and the bus at 16
                when "00001" => adc1 <=
                    x"00000" & m_axis_tdata(15 downto 4); -- 1
                    sample_pulse1 <= '1';

                when "01001" => adc2 <=
                    x"00000" & m_axis_tdata(15 downto 4); -- 9
                    sample_pulse2 <= '1';

                when "00110" => adc3 <=
                    x"00000" & m_axis_tdata(15 downto 4); -- 6
                    sample_pulse3 <= '1';

                when others =>
                    null; -- does nothing

            end case;

        end if;

    end if;
end process;

end Behavioral;
