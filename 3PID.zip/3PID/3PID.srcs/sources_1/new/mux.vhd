----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/19/2026 10:42:26 PM
-- Design Name: 
-- Module Name: mux - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity mux is
	port (
		IN0, IN1, IN2, IN3 : in std_logic_vector(31 downto 0);
		p, i ,d : in std_logic;
		OUT0, OUT1 ,OUT2, OUT3 : out std_logic_vector (31 downto 0)
    );
end mux;

architecture Behavioral of mux is
begin
    process(IN0, IN1, IN2, IN3, p, i ,d)
    begin
        case p is            
            when '1' => OUT0 <= IN0;
            when others => OUT0 <= (others => '0');
        end case;
        case i is            
            when '1' => OUT1 <= IN1;
            when others => OUT1 <= (others => '0');
        end case;
        case d is            
            when '1' =>
                OUT2 <= IN2;
                OUT3 <= IN3;
            when others =>
                OUT2 <= (others => '0');
                OUT3 <= (others => '0');                   
        end case;
    end process;
end Behavioral;

