----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/18/2026 09:31:03 PM
-- Design Name: 
-- Module Name: FSM - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;


entity FSM is
  port(
    clk, en_sw, pwm_sw, next_page : in std_logic;
    btn1, btn2, btn3 : in std_logic;
    led5_r, led5_g, led5_b : out std_logic;
    led4_r, led4_g, led4_b : out std_logic;
    led1, led2, led3 : out std_logic;
    en1, en2, en3 : out std_logic;
    res1, res2, res3 : out std_logic;
    mode1, mode2, mode3 : out std_logic;
    p1, i1, d1 : out std_logic;
    p2, i2, d2 : out std_logic;
    p3, i3, d3 : out std_logic
  ); 
end FSM;

architecture Behavioral of FSM is
    -- dichiarazioni degli stati e dei segnali per tenere traccia dello stato corrente e impostare quello successivo 
    type state is (OFF, PWM, S0, S1, S2, S3, S4);
    signal currentState, nextState : state := OFF;
    signal next_page_old : std_logic := '0';
    signal btn1_old, btn2_old, btn3_old : std_logic := '0';
    
    -- we need to use this in order not to operate with out signals
    signal en1_s, en2_s, en3_s : std_logic := '0';
    signal res1_s, res2_s, res3_s : std_logic := '0';
    signal mode1_s, mode2_s, mode3_s : std_logic := '0';
    signal p1_s, i1_s, d1_s : std_logic := '1';
    signal p2_s, i2_s, d2_s : std_logic := '1';
    signal p3_s, i3_s, d3_s : std_logic := '1';
    
    begin
    
    en1 <= en1_s;
    en2 <= en2_s;
    en3 <= en3_s;
    
    res1 <= res1_s;
    res2 <= res2_s;
    res3 <= res3_s;
    
    mode1 <= mode1_s;
    mode2 <= mode2_s;
    mode3 <= mode3_s;
    
    p1 <= p1_s;
    i1 <= i1_s;
    d1 <= d1_s;
    
    p2 <= p2_s;
    i2 <= i2_s;
    d2 <= d2_s;
    
    p3 <= p3_s;
    i3 <= i3_s;
    d3 <= d3_s;
    
    -- changing pages
    pagesProc : process (currentState, next_page, next_page_old, en_sw, pwm_sw)
    begin
        nextState <= currentState; 
        -- menu interface
        if en_sw = '0' then
            nextState <= OFF;
        elsif pwm_sw = '1' then
            nextState <= PWM;     
        else
            case currentState is   
                when S0 => 
                     if next_page = '1' and next_page_old = '0' then
                        nextState <= S1;
                     end if; 
    
                when S1 => 
                     if next_page = '1' and next_page_old = '0' then
                        nextState <= S2;
                     end if; 
    
                when S2 => 
                     if next_page = '1' and next_page_old = '0' then
                        nextState <= S3;
                     end if; 
    
                when S3 => 
                     if next_page = '1' and next_page_old = '0' then
                        nextState <= S4;
                     end if; 
    
                when S4 => 
                      if next_page = '1' and next_page_old = '0' then
                        nextState <= S0;
                     end if;
                
                when others => nextState <= S0; -- if problems the state goes always on first menu page
            
            end case;
        end if;  
    end process; 
    
    -- rg led codification for each page
    ledProc : process (currentState, en1_s, en2_s, en3_s,
                                     p1_s, i1_s, d1_s,
                                     p2_s, i2_s, d2_s,
                                     p3_s, i3_s, d3_s)
    begin
        led1 <= '0';
        led2 <= '0';
        led3 <= '0';
        
        led4_r <= '0';
        led4_g <= '0';
        led4_b <= '0';
        
        led5_r <= '0';
        led5_g <= '0';
        led5_b <= '0';
        
        if currentState = OFF then
            -- red
            led5_r <= '1';
        elsif currentState = PWM then
            -- yellow
            led5_r <= '1';
            led5_g <= '1';
            
            led1 <= mode1_s;
            led2 <= mode2_s;
            led3 <= mode3_s;
            
        else
            led5_g <= '1';
            
            case currentState is
                when S0 =>
                     -- white
                     led4_r <= '1';
                     led4_g <= '1';
                     led4_b <= '1';
                     
                     led1 <= en1_s;
                     led2 <= en2_s;
                     led3 <= en3_s;
                     
                when S1 =>
                     -- red
                     led4_r <= '1';
                     
                     -- this makes res impulse so no need to turn on the leds
                     
                when S2 => 
                     -- blue
                     led4_b <= '1';
                     
                     led1 <= p1_s;
                     led2 <= i1_s;
                     led3 <= d1_s;
                     
                when S3 => 
                     -- green
                     led4_g <= '1';
                     
                     led1 <= p2_s;
                     led2 <= i2_s;
                     led3 <= d2_s;
                     
                when S4 =>
                     -- yellow
                     led4_r <= '1';
                     led4_g <= '1';
                     
                     led1 <= p3_s;
                     led2 <= i3_s;
                     led3 <= d3_s; 
                
                -- error     
                when others =>                
                    led4_r <= '1';
                    led5_r <= '1';
                    led1 <= '1';
                    led2 <= '1'; 
                    led3 <= '1';
            end case;
        end if;
    end process;
    
    -- syncronous states/logic for every page
    pageLogicProc : process(clk)
    begin
        if rising_edge(clk) then
            currentState <= nextState;
            next_page_old <= next_page;
            
            btn1_old <= btn1;
            btn2_old <= btn2;
            btn3_old <= btn3;
    
            -- to make reset as an impulse
            res1_s <= '0';
            res2_s <= '0';
            res3_s <= '0';
    
        case currentState is
            when OFF =>
                en1_s <= '0';
                en2_s <= '0';
                en3_s <= '0';
                
                res1_s <= '1';
                res2_s <= '1';
                res3_s <= '1';
                
            when PWM =>
                if btn1 = '1' and btn1_old = '0' then
                    mode1_s <= not mode1_s;
                end if;

                if btn2 = '1' and btn2_old = '0' then
                    mode2_s <= not mode2_s;
                end if;

                if btn3 = '1' and btn3_old = '0' then
                    mode3_s <= not mode3_s;
                end if;
            when S0 =>
                if btn1 = '1' and btn1_old = '0' then
                    en1_s <= not en1_s;
                end if;

                if btn2 = '1' and btn2_old = '0' then
                    en2_s <= not en2_s;
                end if;

                if btn3 = '1' and btn3_old = '0' then
                    en3_s <= not en3_s;
                end if;

            when S1 =>
                if btn1 = '1' and btn1_old = '0' then
                    res1_s <= '1';
                end if;

                if btn2 = '1' and btn2_old = '0' then
                    res2_s <= '1';
                end if;

                if btn3 = '1' and btn3_old = '0' then
                    res3_s <= '1';
                end if;

            when S2 =>
                if btn1 = '1' and btn1_old = '0' then
                    p1_s <= not p1_s;
                end if;

                if btn2 = '1' and btn2_old = '0' then
                    i1_s <= not i1_s;
                end if;

                if btn3 = '1' and btn3_old = '0' then
                    d1_s <= not d1_s;
                end if;
                
            when S3 =>
                if btn1 = '1' and btn1_old = '0' then
                    p2_s <= not p2_s;
                end if;

                if btn2 = '1' and btn2_old = '0' then
                    i2_s <= not i2_s;
                end if;

                if btn3 = '1' and btn3_old = '0' then
                    d2_s <= not d2_s;
                end if;

            when S4 =>
                if btn1 = '1' and btn1_old = '0' then
                    p3_s <= not p3_s;
                end if;

                if btn2 = '1' and btn2_old = '0' then
                    i3_s <= not i3_s;
                end if;

                if btn3 = '1' and btn3_old = '0' then
                    d3_s <= not d3_s;
                end if;
         -- when others =>
                
        end case;
    end if;
    
end process;
    
end Behavioral;
