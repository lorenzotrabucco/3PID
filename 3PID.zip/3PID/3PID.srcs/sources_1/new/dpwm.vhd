----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 23.04.2026 14:48:19
-- Design Name: 
-- Module Name: dpwm - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity dpwm is
  generic ( 
    N : integer := 24 -- 24 so that we can decide the number of bits of the counter in runtime up to this number
  );
  port ( 
    pwm : out std_logic;
    clk, en, res : in std_logic;
    duty : in std_logic_vector(N-1 downto 0);
    mode : in  std_logic;  -- 0 = edge-aligned, 1 = center-aligned
    q_max: in std_logic_vector(N-1 downto 0) -- configurable max value of counter (period)
  );
end dpwm;

architecture Behavioral of dpwm is

  signal cnt: unsigned(N-1 downto 0);
  
  component counter
    generic(N : integer);
    port ( 
      clk, en, res : in std_logic;
      preset : in unsigned(N-1 downto 0);
      mode : in  std_logic; -- 0 = down/reset 1 = up/down
      q : out unsigned(N-1 downto 0)
    );
  end component;    
    
begin
  
  CNT_ENTITY: counter
  generic map(N=>N)
  port map(
    clk => clk, 
    en => en,
    res => res,
    preset => unsigned(q_max),
    mode => mode,
    q => cnt
  );
  
  CalcoloPwm: process(cnt,duty,res)
  begin  
    if res = '1' then
       pwm <= '0'; 
    else
        if unsigned(duty) = 0 then
            pwm <= '0';
        elsif unsigned(duty) = unsigned(q_max) then
            pwm <= '1'; 
        elsif cnt <= unsigned(duty) then
            pwm <= '1';
        else
            pwm <= '0'; 
        end if;
    end if;
  end process; 
   
end Behavioral;