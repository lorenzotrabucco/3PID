----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 04/17/2025 03:17:36 PM
-- Design Name: 
-- Module Name: counter - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity counter is
  generic(N : integer := 8);
  port ( 
    clk, en, res, load : in std_logic;
    preset : in unsigned(N-1 downto 0);
    q : out unsigned(N-1 downto 0)
  );
end counter;

architecture Behavioral of counter is

  --signal cnt : unsigned(N-1 downto 0) := (others => '0');
  signal cnt : unsigned(N-1 downto 0) := to_unsigned(0,N);

begin

  -- Output definition
  q <= cnt;
  
  -- Counter definition
  cntProc: process(clk,res)
  begin
    if res = '1' then
      cnt <= (others => '0');
    elsif rising_edge(clk) then
      cnt <= cnt;
      if en = '1' then
        if load = '1' then
          cnt <= preset;
        else
          cnt <= cnt-1;
        end if;
      end if;
    end if;
  end process;

end Behavioral;
