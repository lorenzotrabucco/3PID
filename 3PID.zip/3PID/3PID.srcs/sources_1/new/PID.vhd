----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/15/2026 02:23:20 PM
-- Design Name: 
-- Module Name: PID - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity PID is
generic(
    data_bits : integer := 32 -- bit used for calculations (block can be used with more or less precision)
);
port(
    clk : in std_logic;
    res : in std_logic;
    en : in std_logic;
    sample_pulse : in std_logic;
    x_ref : in signed(data_bits-1 downto 0);
    
    -- input
    x : in signed(data_bits-1 downto 0);
    
    -- output borders (1+31.0 format)
    y_max : in signed(data_bits-1 downto 0);
    y_min : in signed(data_bits-1 downto 0);
    
    -- output (1+31.0 format)
    y : out signed(data_bits-1 downto 0);
    
   -- frac_bits : in unsigned(5 downto 0); -- number of fractional bit
    
    -- PID parameters (given in 1+15.16 format, we give always half bits for integer and half for fractional part)
    kp : in signed(data_bits-1 downto 0);
    kiTc : in signed(data_bits-1 downto 0);
    
    C1 : in signed(data_bits-1 downto 0); -- should be always < 1 so format 1.31 is better
    C2 : in signed(data_bits-1 downto 0)
);
end PID;

architecture Behavioral of PID is

constant acc_bits : integer := 2*data_bits; -- accumulator number of bits for multiplications
constant half_bits : integer := data_bits/2; -- useful half value

-- previous values
signal yi_old : signed(acc_bits-1 downto 0) := (others => '0');
signal yd_old : signed(data_bits-1 downto 0) := (others => '0');
signal x_old : signed(data_bits-1 downto 0) := (others => '0');

-- current values
signal yp : signed(acc_bits-1 downto 0) := (others => '0');
signal yi : signed(acc_bits-1 downto 0) := (others => '0');
signal yd : signed(acc_bits-1 downto 0) := (others => '0');

begin

process(clk,res)
    
    -- local variables for computation
    variable e : signed(data_bits-1 downto 0);
    variable delta_x : signed(data_bits-1 downto 0);
    
    -- accumulators to store the result of the multiplications temporarily
    variable yp_acc : signed(acc_bits-1 downto 0);
    variable yi_acc : signed(acc_bits-1 downto 0);
    variable yd_acc : signed(acc_bits-1 downto 0);
    variable C1_acc : signed(acc_bits-1 downto 0);
    variable C2_acc : signed(acc_bits-1 downto 0);
    variable yi_next : signed(acc_bits-1 downto 0);
    variable y_next : signed(acc_bits-1 downto 0);
    variable y_comp : signed(data_bits+half_bits-1 downto 0);
    variable y_max_comp : signed(data_bits+half_bits-1 downto 0);
    variable y_min_comp : signed(data_bits+half_bits-1 downto 0);

begin
    -- reset
    if res = '1' then
        yi_old <= (others => '0');
        yd_old <= (others => '0');
        yp <= (others => '0');
        yi <= (others => '0');
        yd <= (others => '0');
        y <= (others => '0');
        x_old <= (others => '0');
    
    elsif rising_edge(clk) then
        if en = '1' and sample_pulse = '1' then --
                
                -- error computation
                e := x_ref - x; -- format 1+31.0
                
             -- PROPORTIONAL BLOCK
                -- yp(k) = kp * e(k)
                yp_acc:= resize(e * kp, acc_bits);
                yp <= yp_acc; -- format 2+46.16
    
             -- INTEGRAL BLOCK
                -- yi(k) = yi(k-1) + kiTc * e(k)
                yi_acc := resize(e * kiTc, acc_bits); -- format 2+46.16
                yi_next := yi_old + yi_acc; -- format 2+46.16
                
             -- DERIVATIVE BLOCK
                -- delta of inputs for derivative block computation
                delta_x := x_old - x; -- format 1+31.0
               
                -- C1 * yd(k-1)
                C1_acc := shift_right(resize(yd_old * C1, acc_bits), half_bits-1); -- format 2+31.31 --> format 2+46.16
                -- C2 * [x(k)-x(k-1)]
                C2_acc := resize(delta_x * C2, acc_bits); -- format 2+46.16
                
                -- yd(k) = C1 * yd(k-1) + C2 * [x(k-1) - x(k)]
                yd_acc := C1_acc + C2_acc;
                yd <= yd_acc; -- format 2+46.16
                
                -- store current yd value
                yd_old <= resize(shift_right(yd_acc, half_bits), data_bits); -- format 1+31.0
    
             -- FULL OUTPUT
                -- y(k) = yp(k) + yi(k) + yd(k)
                y_next := yp_acc + yi_next + yd_acc; -- format 2+46.16
                
             -- SATURATION and ANTI WIND-UP (easy algorithm)
                -- casting to 3/2 of data_bits for comparisons
                y_comp := resize(shift_right(y_next, half_bits), half_bits+data_bits); -- format 2+34.0
                y_max_comp := resize(y_max, half_bits+data_bits);
                y_min_comp := resize(y_min, half_bits+data_bits);
                
                if  y_comp >= y_max_comp then
                    y <= y_max;
                    if e > 0 then
                        yi_next := yi_old;  
                    end if;  
                elsif  y_comp <= y_min_comp then
                    y <= y_min;
                    if e < 0 then
                        yi_next := yi_old;  
                    end if;
                else
                    y <= resize(y_comp, data_bits);
                end if;
                
                -- yi uptdating
                yi <= yi_next;
    
                -- store current yi and x value
                yi_old <= yi_next;
                x_old <= x;
    
            end if;
        end if;

end process;

end Behavioral;