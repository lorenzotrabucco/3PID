----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/19/2026 10:02:56 AM
-- Design Name: 
-- Module Name: FSM_tb - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity FSM_tb is
end FSM_tb;

architecture Behavioral of FSM_tb is

    constant CLK_PERIOD : time := 10 ns;

    -- FSM importation
    component FSM
      port(
        clk, en_sw, pwm_sw, next_page : in std_logic;
        btn1, btn2, btn3 : in std_logic;

        led5_r, led5_g, led5_b : out std_logic;
        led4_r, led4_g, led4_b : out std_logic;

        led1, led2, led3 : out std_logic;

        en1, en2, en3 : out std_logic;
        res1, res2, res3 : out std_logic;

        mode1, mode2, mode3 : out std_logic;

        p1, i1, d1 : out std_logic;
        p2, i2, d2 : out std_logic;
        p3, i3, d3 : out std_logic
      );
    end component;

    -- signals used for test
    signal clk : std_logic := '0';

    signal en_sw     : std_logic := '0';
    signal pwm_sw    : std_logic := '0';
    signal next_page : std_logic := '0';

    signal btn1 : std_logic := '0';
    signal btn2 : std_logic := '0';
    signal btn3 : std_logic := '0';

    signal led5_r, led5_g, led5_b : std_logic;
    signal led4_r, led4_g, led4_b : std_logic;

    signal led1, led2, led3 : std_logic;

    signal en1, en2, en3 : std_logic;
    signal res1, res2, res3 : std_logic;

    signal mode1, mode2, mode3 : std_logic;

    signal p1, i1, d1 : std_logic;
    signal p2, i2, d2 : std_logic;
    signal p3, i3, d3 : std_logic;

begin

    -- mapping of internal simulation signals to component ports
    UUT : FSM
    port map(

        clk => clk,
        en_sw => en_sw,
        pwm_sw => pwm_sw,
        next_page => next_page,

        btn1 => btn1,
        btn2 => btn2,
        btn3 => btn3,

        led5_r => led5_r,
        led5_g => led5_g,
        led5_b => led5_b,

        led4_r => led4_r,
        led4_g => led4_g,
        led4_b => led4_b,

        led1 => led1,
        led2 => led2,
        led3 => led3,

        en1 => en1,
        en2 => en2,
        en3 => en3,

        res1 => res1,
        res2 => res2,
        res3 => res3,

        mode1 => mode1,
        mode2 => mode2,
        mode3 => mode3,

        p1 => p1,
        i1 => i1,
        d1 => d1,

        p2 => p2,
        i2 => i2,
        d2 => d2,

        p3 => p3,
        i3 => i3,
        d3 => d3
    );

    -- process to generate clk signal
    clk_proc : process
    begin
        clk <= '1' after CLK_PERIOD/2,
               '0' after CLK_PERIOD;

        wait for CLK_PERIOD;
    end process;

    -- process to generate stimulus signals
    stim_proc : process
    begin

        -- initial state: system off
        wait for 100 us;

        -- turning on system
        en_sw <= '1';
        wait for 100 us;
        
        -- enable page (S0)
        -- enabling PID1, PID2 and PID3, simulating button pressing
        btn1 <= '1';
        wait for 20 us;
        btn1 <= '0';

        wait for 100 us;

        btn2 <= '1';
        wait for 20 us;
        btn2 <= '0';

        wait for 100 us;

        btn3 <= '1';
        wait for 20 us;
        btn3 <= '0';

        wait for 200 us;

        -- moving to reset page (S1)
        next_page <= '1';
        wait for 20 us;
        next_page <= '0';

        wait for 200 us;

        -- resetting PID1, PID2, PID3
        btn1 <= '1';
        wait for 20 us;
        btn1 <= '0';
        
        wait for 100 us;

        btn2 <= '1';
        wait for 20 us;
        btn2 <= '0';

        wait for 100 us;

        btn3 <= '1';
        wait for 20 us;
        btn3 <= '0';
        
        wait for 200 us;

        -- moving to PID1 configuration page (S2)
        next_page <= '1';
        wait for 20 us;
        next_page <= '0';

        wait for 200 us;

        -- toggling P, I and D terms of PID1
        btn1 <= '1';
        wait for 20 us;
        btn1 <= '0';

        wait for 100 us;

        btn2 <= '1';
        wait for 20 us;
        btn2 <= '0';

        wait for 100 us;

        btn3 <= '1';
        wait for 20 us;
        btn3 <= '0';

        wait for 200 us;

        -- moving to PID2 configuration page (S3)
        next_page <= '1';
        wait for 20 us;
        next_page <= '0';

        wait for 200 us;

        -- toggling P, I and D terms of PID2
        btn1 <= '1';
        wait for 20 us;
        btn1 <= '0';

        wait for 100 us;

        btn2 <= '1';
        wait for 20 us;
        btn2 <= '0';

        wait for 100 us;

        btn3 <= '1';
        wait for 20 us;
        btn3 <= '0';

        wait for 200 us;
        
        -- moving to PID3 configuration page (S4)
        next_page <= '1';
        wait for 20 us;
        next_page <= '0';

        wait for 200 us;

        -- toggling P, I and D terms of PID3
        btn1 <= '1';
        wait for 20 us;
        btn1 <= '0';

        wait for 100 us;

        btn2 <= '1';
        wait for 20 us;
        btn2 <= '0';

        wait for 100 us;

        btn3 <= '1';
        wait for 20 us;
        btn3 <= '0';

        wait for 200 us;

        -- enabling PWM configuration page (PWM)
        pwm_sw <= '1';

        wait for 300 us;

        -- changing PWM modes for each PWM
        btn1 <= '1';
        wait for 20 us;
        btn1 <= '0';

        wait for 100 us;

        btn2 <= '1';
        wait for 20 us;
        btn2 <= '0';

        wait for 100 us;

        btn3 <= '1';
        wait for 20 us;
        btn3 <= '0';

        wait for 200 us;

        -- disabling PWM configuration page
        pwm_sw <= '0';

        wait for 200 us;

        -- turning system off
        en_sw <= '0';

        wait for 200 us;

        wait;

    end process;

end Behavioral;