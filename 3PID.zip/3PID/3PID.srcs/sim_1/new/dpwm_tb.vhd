----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 23.04.2026 16:37:39
-- Design Name: 
-- Module Name: dpwm_tb - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;


--DUTY = 0 fino a 0.5ms, 128 fino a 1ms, 255 fino a 1.5ms;
--RESET= 0 fino a 0.6ms, 1 fino a 0.7ms.
--ENABLE = 1

entity dpwm_tb is
--  Port ( );
end dpwm_tb;

architecture Behavioral of dpwm_tb is
    
    --IMPORTAZIONE DPWM
    component dpwm
    generic(
        N : integer 
    );
    port ( 
      pwm : out std_logic;
      clk, en, res : in std_logic;
      duty : in std_logic_vector(N-1 downto 0);
      mode : in  std_logic; -- 0 = edge-aligned, 1 = center-aligned
      q_max: in std_logic_vector(N-1 downto 0) -- configurable max value of counter (period)
    );
    end component;

    -- variabili utilizzate per il test    
    constant N : integer := 8;
    constant CLK_PERIOD : time := 10 ns; -- dalle specifiche ho clock a 100 MHz
    signal clk,res   : std_logic := '0';
    signal en    : std_logic := '1';
    signal duty  : std_logic_vector(N-1 downto 0);
    signal pwm   : std_logic;
    signal mode : std_logic;
    signal q_max : std_logic_vector(N-1 downto 0); -- configurable max value of counter (period)
    
begin
    
    -- Associazione dei segnali interni di simulazione alle porte del componente
    UUT: dpwm
        generic map(N => N)
        port map(
            clk  => clk,
            en   => en,
            res  => res,
            duty => duty,
            pwm  => pwm,
            mode => mode,
            q_max => q_max
        );
      
    -- Processo per generazione del segnale di clk 
    clk_proc: process
    begin
        clk <= '1' after CLK_PERIOD /2, '0' after CLK_PERIOD;
        wait for CLK_PERIOD;
    end process;

    -- Processo per generazione dei segnali di stimolo    
    stim_proc: process
        begin
        
        q_max <= "11111111";
        mode <= '0'; -- edge aligned
        duty <= (others => '0');
        wait for 0.5 ms; 
        duty <= "10000000";        
        wait for 0.1 ms;  
        res <= '1';
        wait for 0.1 ms;  
        res <= '0';        
        wait for 0.3 ms;
        duty <= (others => '1');
        wait for 0.5 ms;
        
        mode <= '1';-- center-aligned
        duty <= (others => '0');
        wait for 0.5 ms; 
        duty <= "10000000";        
        wait for 0.1 ms;  
        res <= '1';
        wait for 0.1 ms;  
        res <= '0';        
        wait for 0.3 ms;
        duty <= (others => '1');
        wait for 0.5 ms;
        en <= '0';        
        
    end process;

end Behavioral;
