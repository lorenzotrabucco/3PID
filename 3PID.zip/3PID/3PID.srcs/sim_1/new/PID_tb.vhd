----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/16/2026 08:42:13 AM
-- Design Name: 
-- Module Name: PID_tb - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity PID_tb is
--  Port ( );
end PID_tb;

architecture Behavioral of PID_tb is
    
    constant data_bits : integer := 24; -- hypothesis: 12 bit adc so format 12.12
    constant CLK_PERIOD : time := 10 ns; -- from the specs we suppose is 100 MHz
    constant ADC_PERIOD : time := 10 us; -- we suppose Tc = 100 kHz of sampling frequency
    constant NOISE_PERIOD : time := 50 us; -- 20kHz noise
    
    -- values of coefficients in the simulated controlled system
    -- supposed tau = 1/(2*pi*ft) where ft = 1kHz
    -- a = tau/tau+Tc = 0.9408826026, b= Tc/tau+Tc = 0.05911739744
    constant a : signed(data_bits-1 downto 0) := to_signed(7892695, data_bits); -- format 1.23 signed
    constant b : signed(data_bits-1 downto 0) := to_signed(495913, data_bits); -- format 1.23 signed
    
    -- PID IMPORTATION
    component PID
        generic(
        data_bits : integer := 24 -- max bit used, we don't care about the format because adc decides it
        );
        port(
            clk : in std_logic;
            res : in std_logic;
            en : in std_logic;
            sample_pulse : in std_logic;
            x_ref : in signed(data_bits-1 downto 0);
            x : in signed(data_bits-1 downto 0);
            
            -- PID parameters
            kp : in signed(data_bits-1 downto 0);
            kiTc : in signed(data_bits-1 downto 0);
        
            C1 : in signed(data_bits-1 downto 0);
            C2 : in signed(data_bits-1 downto 0);
        
            -- output borders
            y_max : in signed(data_bits-1 downto 0);
            y_min : in signed(data_bits-1 downto 0);
            
            -- output
            y : out signed(data_bits-1 downto 0)
        );
    end component;
    -- PID parameters used for test
    signal clk, res, en, sample_pulse   : std_logic := '0';
    signal x_ref : signed(data_bits-1 downto 0) := (others => '0');
    signal x : signed(data_bits-1 downto 0) := (others => '0');
    signal kp : signed(data_bits-1 downto 0) := (others => '0');
    signal kiTc : signed(data_bits-1 downto 0) := (others => '0');
    signal C1 : signed(data_bits-1 downto 0) := (others => '0');
    signal C2 : signed(data_bits-1 downto 0) := (others => '0');
    signal y_max : signed(data_bits-1 downto 0) := x"7fffff"; -- max value on 24 bits signed
    signal y_min : signed(data_bits-1 downto 0) := (others => '0'); -- already right
    signal y : signed(data_bits-1 downto 0) := (others => '0');
    
    -- system parameters used for test
    signal x_old : signed(data_bits-1 downto 0) := (others => '0');
    
    -- noise
    signal noise_flag : std_logic := '0';
    signal noise : signed(data_bits-1 downto 0) := (others => '0');
    
begin
    
    -- mapping of internal simulation signals to the component ports
    UUT: PID
        generic map(data_bits => data_bits)
        port map(
            clk => clk,
            res  => res,
            en => en,
            sample_pulse => sample_pulse,  
            x_ref => x_ref,
            x => x,
            kp => kp,
            kiTc => kiTc,
            C1 => C1,
            C2 => C2,
            y_max => y_max,
            y_min => y_min,
            y => y
        );

    -- process to generate clk signal
    clk_proc: process
    begin
        clk <= '1' after CLK_PERIOD /2, '0' after CLK_PERIOD;
        wait for CLK_PERIOD;
    end process;
    
    noise_proc: process
    begin
        if noise_flag = '1' then
            noise <= x"020000" after NOISE_PERIOD/2, x"FE0000" after NOISE_PERIOD; -- 1/64 of full input range
            wait for NOISE_PERIOD;
        else
            noise <= (others => '0');
            wait for CLK_PERIOD;
        end if;
    end process;
    
    adc_proc: process
    
    variable adc_acc : signed(data_bits*2-1 downto 0) := (others => '0'); -- accumulator
    variable x_tmp : signed(data_bits-1 downto 0) := (others => '0'); -- variable for updating signals immediately
    
    begin
        wait for 1 us;
        -- definition of the system to control and updating it
        -- x(k) = a*x(k-1) + b*y(k)
        adc_acc := a*x_old + b*y;
        x_tmp := resize(shift_right(adc_acc, data_bits-1), data_bits);
        
        x <= x_tmp + noise;
        x_old <= x_tmp;
        
        -- generation of sampling impulse ('1' only for a clk period)
        sample_pulse <= '1';
        wait for CLK_PERIOD;    
        sample_pulse <= '0';    
        wait for ADC_PERIOD - CLK_PERIOD;
        
    end process;

    -- process to generate stimulus signals
    stim_proc: process
        begin
        -- y_max and y_min already given correct
        res <= '1';
        wait for 0.5 ms;
        res <= '0';
        en <= '1';   
        -- hexadecimal used for simplicity
        
     -- TEST 1 (PI)
        kp <= x"00A000"; -- 10 (1+11.12)
        kiTc <= x"000100"; -- 1 (1+11.12) because stating that the pole of the system is the same as the zero of the PI block and with 10kHz of loop bandwidth, is a little more to show a bigger oscillation
        C1 <= x"000000"; -- 0 (1+11.12)
        C2 <= x"000000"; -- 0 (1+11.12)
        x_ref <= x"700000"; -- 50% (1+23.0)
        wait for 1 ms;
        x_ref <= x"000000"; -- back to 0%
        wait for 1 ms;
        
        res <= '1';
        wait for 0.5 ms;
        res <= '0';
        
     -- TEST 2 (PID)
        kp <= x"00A000"; -- 10 (1+11.12)
        kiTc <= x"001000"; -- 1 (1+11.12) because stating that the pole of the system is the same as the zero of the PI block and with 10kHz of loop bandwidth, is a little more to show a bigger oscillation
        C1 <= x"786ED7"; -- same as a: 0.9408826026 (1.23) (pole of derivative block imposed as the pole of the system)
        C2 <= x"00019A"; -- 0.10 (1+11.12) reasonable value
        x_ref <= x"700000"; -- 50% (1+23.0)
        wait for 1 ms;
        x_ref <= x"000000"; -- back to 0%
        wait for 1 ms;
        
        res <= '1';
        wait for 0.5 ms;
        res <= '0';
        
     -- TEST 3 (PID, adding noise to see derivative effect problem)
        noise_flag <= '1';
        C1 <= x"38B8B9"; -- 0.4431372759 (1.23) changing derivative pole (to 20kHz)  
        C2 <= x"000F12"; -- 0.9419608242 (1+11.12) reasonable value
        x_ref <= x"700000"; -- 50% (1+23.0)
        wait for 1 ms;
        x_ref <= x"000000"; -- back to 0%  
        wait for 1 ms;
        en <= '0';
        noise_flag <= '0';
        wait for 0.1 ms;
        
        res <= '1';
        wait for 0.1 ms;
        
    end process;

end Behavioral;

