--Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
--Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
--Date        : Wed Oct 21 19:32:56 2026
--Host        : DTG-LabEle25-02 running 64-bit major release  (build 9200)
--Command     : generate_target system_wrapper.bd
--Design      : system_wrapper
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity system_wrapper is
  port (
    Vaux1_v_p : in STD_LOGIC;
    Vaux6_v_p : in STD_LOGIC;
    Vaux9_v_p : in STD_LOGIC;
    a_3 : out STD_LOGIC;
    a_4 : out STD_LOGIC;
    a_5 : out STD_LOGIC;
    btn_0 : in STD_LOGIC;
    btn_1 : in STD_LOGIC;
    btn_2 : in STD_LOGIC;
    btn_3 : in STD_LOGIC;
    jb_0 : out STD_LOGIC;
    jb_1 : out STD_LOGIC;
    jb_2 : out STD_LOGIC;
    led4_b : out STD_LOGIC;
    led4_g : out STD_LOGIC;
    led4_r : out STD_LOGIC;
    led5_b : out STD_LOGIC;
    led5_g : out STD_LOGIC;
    led5_r : out STD_LOGIC;
    led_0 : out STD_LOGIC;
    led_1 : out STD_LOGIC;
    led_2 : out STD_LOGIC;
    led_3 : out STD_LOGIC;
    sw_0 : in STD_LOGIC;
    sw_1 : in STD_LOGIC
  );
end system_wrapper;

architecture STRUCTURE of system_wrapper is
  component system is
  port (
    jb_0 : out STD_LOGIC;
    jb_1 : out STD_LOGIC;
    jb_2 : out STD_LOGIC;
    a_3 : out STD_LOGIC;
    a_4 : out STD_LOGIC;
    a_5 : out STD_LOGIC;
    Vaux1_v_p : in STD_LOGIC;
    Vaux9_v_p : in STD_LOGIC;
    Vaux6_v_p : in STD_LOGIC;
    sw_0 : in STD_LOGIC;
    sw_1 : in STD_LOGIC;
    led4_r : out STD_LOGIC;
    led4_g : out STD_LOGIC;
    led4_b : out STD_LOGIC;
    led5_r : out STD_LOGIC;
    led5_g : out STD_LOGIC;
    led5_b : out STD_LOGIC;
    led_0 : out STD_LOGIC;
    led_1 : out STD_LOGIC;
    led_2 : out STD_LOGIC;
    led_3 : out STD_LOGIC;
    btn_0 : in STD_LOGIC;
    btn_1 : in STD_LOGIC;
    btn_2 : in STD_LOGIC;
    btn_3 : in STD_LOGIC
  );
  end component system;
begin
system_i: component system
     port map (
      Vaux1_v_p => Vaux1_v_p,
      Vaux6_v_p => Vaux6_v_p,
      Vaux9_v_p => Vaux9_v_p,
      a_3 => a_3,
      a_4 => a_4,
      a_5 => a_5,
      btn_0 => btn_0,
      btn_1 => btn_1,
      btn_2 => btn_2,
      btn_3 => btn_3,
      jb_0 => jb_0,
      jb_1 => jb_1,
      jb_2 => jb_2,
      led4_b => led4_b,
      led4_g => led4_g,
      led4_r => led4_r,
      led5_b => led5_b,
      led5_g => led5_g,
      led5_r => led5_r,
      led_0 => led_0,
      led_1 => led_1,
      led_2 => led_2,
      led_3 => led_3,
      sw_0 => sw_0,
      sw_1 => sw_1
    );
end STRUCTURE;
