--Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
--Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
--Date        : Wed Oct 21 19:33:17 2026
--Host        : DTG-LabEle25-02 running 64-bit major release  (build 9200)
--Command     : generate_target PID_dpwm_chain_x3_inst_0_wrapper.bd
--Design      : PID_dpwm_chain_x3_inst_0_wrapper
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity PID_dpwm_chain_x3_inst_0_wrapper is
  port (
    C1_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clk_0 : in STD_LOGIC;
    en_0 : in STD_LOGIC;
    en_1 : in STD_LOGIC;
    en_2 : in STD_LOGIC;
    kiTc_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kiTc_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kiTc_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    mode_0 : in STD_LOGIC;
    mode_1 : in STD_LOGIC;
    mode_2 : in STD_LOGIC;
    pwm_0 : out STD_LOGIC;
    pwm_1 : out STD_LOGIC;
    pwm_2 : out STD_LOGIC;
    q_max_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    q_max_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    q_max_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    res_0 : in STD_LOGIC;
    res_1 : in STD_LOGIC;
    res_2 : in STD_LOGIC;
    sample_pulse_0 : in STD_LOGIC;
    sample_pulse_1 : in STD_LOGIC;
    sample_pulse_2 : in STD_LOGIC;
    x_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_2 : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
end PID_dpwm_chain_x3_inst_0_wrapper;

architecture STRUCTURE of PID_dpwm_chain_x3_inst_0_wrapper is
  component PID_dpwm_chain_x3_inst_0 is
  port (
    clk_0 : in STD_LOGIC;
    C1_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    en_0 : in STD_LOGIC;
    kiTc_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    res_0 : in STD_LOGIC;
    sample_pulse_0 : in STD_LOGIC;
    x_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    en_1 : in STD_LOGIC;
    kiTc_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    res_1 : in STD_LOGIC;
    sample_pulse_1 : in STD_LOGIC;
    x_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    en_2 : in STD_LOGIC;
    kiTc_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    res_2 : in STD_LOGIC;
    sample_pulse_2 : in STD_LOGIC;
    x_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    pwm_0 : out STD_LOGIC;
    pwm_1 : out STD_LOGIC;
    pwm_2 : out STD_LOGIC;
    mode_0 : in STD_LOGIC;
    q_max_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    mode_1 : in STD_LOGIC;
    q_max_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    mode_2 : in STD_LOGIC;
    q_max_2 : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  end component PID_dpwm_chain_x3_inst_0;
begin
PID_dpwm_chain_x3_inst_0_i: component PID_dpwm_chain_x3_inst_0
     port map (
      C1_0(31 downto 0) => C1_0(31 downto 0),
      C1_1(31 downto 0) => C1_1(31 downto 0),
      C1_2(31 downto 0) => C1_2(31 downto 0),
      C2_0(31 downto 0) => C2_0(31 downto 0),
      C2_1(31 downto 0) => C2_1(31 downto 0),
      C2_2(31 downto 0) => C2_2(31 downto 0),
      clk_0 => clk_0,
      en_0 => en_0,
      en_1 => en_1,
      en_2 => en_2,
      kiTc_0(31 downto 0) => kiTc_0(31 downto 0),
      kiTc_1(31 downto 0) => kiTc_1(31 downto 0),
      kiTc_2(31 downto 0) => kiTc_2(31 downto 0),
      kp_0(31 downto 0) => kp_0(31 downto 0),
      kp_1(31 downto 0) => kp_1(31 downto 0),
      kp_2(31 downto 0) => kp_2(31 downto 0),
      mode_0 => mode_0,
      mode_1 => mode_1,
      mode_2 => mode_2,
      pwm_0 => pwm_0,
      pwm_1 => pwm_1,
      pwm_2 => pwm_2,
      q_max_0(31 downto 0) => q_max_0(31 downto 0),
      q_max_1(31 downto 0) => q_max_1(31 downto 0),
      q_max_2(31 downto 0) => q_max_2(31 downto 0),
      res_0 => res_0,
      res_1 => res_1,
      res_2 => res_2,
      sample_pulse_0 => sample_pulse_0,
      sample_pulse_1 => sample_pulse_1,
      sample_pulse_2 => sample_pulse_2,
      x_0(31 downto 0) => x_0(31 downto 0),
      x_1(31 downto 0) => x_1(31 downto 0),
      x_2(31 downto 0) => x_2(31 downto 0),
      x_ref_0(31 downto 0) => x_ref_0(31 downto 0),
      x_ref_1(31 downto 0) => x_ref_1(31 downto 0),
      x_ref_2(31 downto 0) => x_ref_2(31 downto 0),
      y_max_0(31 downto 0) => y_max_0(31 downto 0),
      y_max_1(31 downto 0) => y_max_1(31 downto 0),
      y_max_2(31 downto 0) => y_max_2(31 downto 0),
      y_min_0(31 downto 0) => y_min_0(31 downto 0),
      y_min_1(31 downto 0) => y_min_1(31 downto 0),
      y_min_2(31 downto 0) => y_min_2(31 downto 0)
    );
end STRUCTURE;
