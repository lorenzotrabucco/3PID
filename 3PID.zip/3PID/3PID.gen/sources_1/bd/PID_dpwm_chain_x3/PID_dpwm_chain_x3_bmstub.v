// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
// -------------------------------------------------------------------------------

`timescale 1 ps / 1 ps

(* BLOCK_STUB = "true" *)
module PID_dpwm_chain_x3 (
  clk_0,
  C1_0,
  C2_0,
  en_0,
  kiTc_0,
  kp_0,
  res_0,
  sample_pulse_0,
  x_0,
  x_ref_0,
  y_max_0,
  y_min_0,
  C1_1,
  C2_1,
  en_1,
  kiTc_1,
  kp_1,
  res_1,
  sample_pulse_1,
  x_1,
  x_ref_1,
  y_max_1,
  y_min_1,
  C1_2,
  C2_2,
  en_2,
  kiTc_2,
  kp_2,
  res_2,
  sample_pulse_2,
  x_2,
  x_ref_2,
  y_max_2,
  y_min_2,
  pwm_0,
  pwm_1,
  pwm_2,
  mode_0,
  q_max_0,
  mode_1,
  q_max_1,
  mode_2,
  q_max_2
);

  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CLK_0 CLK" *)
  (* X_INTERFACE_MODE = "slave CLK.CLK_0" *)
  (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CLK_0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, PHASE 0.0, CLK_DOMAIN PID_dpwm_chain_x3_clk_0, INSERT_VIP 0" *)
  input clk_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]C1_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]C2_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input en_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]kiTc_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]kp_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input res_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input sample_pulse_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]x_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]x_ref_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]y_max_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]y_min_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]C1_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]C2_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input en_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]kiTc_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]kp_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input res_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input sample_pulse_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]x_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]x_ref_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]y_max_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]y_min_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]C1_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]C2_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input en_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]kiTc_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]kp_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input res_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input sample_pulse_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]x_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]x_ref_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]y_max_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [31:0]y_min_2;
  (* X_INTERFACE_IGNORE = "true" *)
  output pwm_0;
  (* X_INTERFACE_IGNORE = "true" *)
  output pwm_1;
  (* X_INTERFACE_IGNORE = "true" *)
  output pwm_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input mode_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input [23:0]q_max_0;
  (* X_INTERFACE_IGNORE = "true" *)
  input mode_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input [23:0]q_max_1;
  (* X_INTERFACE_IGNORE = "true" *)
  input mode_2;
  (* X_INTERFACE_IGNORE = "true" *)
  input [23:0]q_max_2;

  // stub module has no contents

endmodule
