--Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
--Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
----------------------------------------------------------------------------------
--Tool Version: Vivado v.2024.2 (win64) Build 5239630 Fri Nov 08 22:35:27 MST 2024
--Date        : Mon Oct 19 23:59:30 2026
--Host        : DTG-LabEle25-02 running 64-bit major release  (build 9200)
--Command     : generate_target PID_dpwm_chain_x3.bd
--Design      : PID_dpwm_chain_x3
--Purpose     : IP block netlist
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
library UNISIM;
use UNISIM.VCOMPONENTS.ALL;
entity PID_dpwm_chain_x3 is
  port (
    C1_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    clk_0 : in STD_LOGIC;
    en_0 : in STD_LOGIC;
    en_1 : in STD_LOGIC;
    en_2 : in STD_LOGIC;
    kiTc_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kiTc_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kiTc_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kp_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    mode_0 : in STD_LOGIC;
    mode_1 : in STD_LOGIC;
    mode_2 : in STD_LOGIC;
    pwm_0 : out STD_LOGIC;
    pwm_1 : out STD_LOGIC;
    pwm_2 : out STD_LOGIC;
    q_max_0 : in STD_LOGIC_VECTOR ( 23 downto 0 );
    q_max_1 : in STD_LOGIC_VECTOR ( 23 downto 0 );
    q_max_2 : in STD_LOGIC_VECTOR ( 23 downto 0 );
    res_0 : in STD_LOGIC;
    res_1 : in STD_LOGIC;
    res_2 : in STD_LOGIC;
    sample_pulse_0 : in STD_LOGIC;
    sample_pulse_1 : in STD_LOGIC;
    sample_pulse_2 : in STD_LOGIC;
    x_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x_ref_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max_2 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_0 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min_2 : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  attribute CORE_GENERATION_INFO : string;
  attribute CORE_GENERATION_INFO of PID_dpwm_chain_x3 : entity is "PID_dpwm_chain_x3,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=PID_dpwm_chain_x3,x_ipVersion=1.00.a,x_ipLanguage=VHDL,numBlks=9,numReposBlks=9,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=6,numPkgbdBlks=0,bdsource=USER,synth_mode=Hierarchical}";
  attribute HW_HANDOFF : string;
  attribute HW_HANDOFF of PID_dpwm_chain_x3 : entity is "PID_dpwm_chain_x3.hwdef";
end PID_dpwm_chain_x3;

architecture STRUCTURE of PID_dpwm_chain_x3 is
  component PID_dpwm_chain_x3_PID_0_0 is
  port (
    clk : in STD_LOGIC;
    res : in STD_LOGIC;
    en : in STD_LOGIC;
    sample_pulse : in STD_LOGIC;
    x_ref : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y : out STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kiTc : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2 : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  end component PID_dpwm_chain_x3_PID_0_0;
  component PID_dpwm_chain_x3_PID_0_1 is
  port (
    clk : in STD_LOGIC;
    res : in STD_LOGIC;
    en : in STD_LOGIC;
    sample_pulse : in STD_LOGIC;
    x_ref : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y : out STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kiTc : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2 : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  end component PID_dpwm_chain_x3_PID_0_1;
  component PID_dpwm_chain_x3_PID_0_2 is
  port (
    clk : in STD_LOGIC;
    res : in STD_LOGIC;
    en : in STD_LOGIC;
    sample_pulse : in STD_LOGIC;
    x_ref : in STD_LOGIC_VECTOR ( 31 downto 0 );
    x : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_max : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y_min : in STD_LOGIC_VECTOR ( 31 downto 0 );
    y : out STD_LOGIC_VECTOR ( 31 downto 0 );
    kp : in STD_LOGIC_VECTOR ( 31 downto 0 );
    kiTc : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C1 : in STD_LOGIC_VECTOR ( 31 downto 0 );
    C2 : in STD_LOGIC_VECTOR ( 31 downto 0 )
  );
  end component PID_dpwm_chain_x3_PID_0_2;
  component PID_dpwm_chain_x3_dpwm_0_0 is
  port (
    pwm : out STD_LOGIC;
    clk : in STD_LOGIC;
    en : in STD_LOGIC;
    res : in STD_LOGIC;
    duty : in STD_LOGIC_VECTOR ( 23 downto 0 );
    mode : in STD_LOGIC;
    q_max : in STD_LOGIC_VECTOR ( 23 downto 0 )
  );
  end component PID_dpwm_chain_x3_dpwm_0_0;
  component PID_dpwm_chain_x3_dpwm_0_1 is
  port (
    pwm : out STD_LOGIC;
    clk : in STD_LOGIC;
    en : in STD_LOGIC;
    res : in STD_LOGIC;
    duty : in STD_LOGIC_VECTOR ( 23 downto 0 );
    mode : in STD_LOGIC;
    q_max : in STD_LOGIC_VECTOR ( 23 downto 0 )
  );
  end component PID_dpwm_chain_x3_dpwm_0_1;
  component PID_dpwm_chain_x3_dpwm_0_2 is
  port (
    pwm : out STD_LOGIC;
    clk : in STD_LOGIC;
    en : in STD_LOGIC;
    res : in STD_LOGIC;
    duty : in STD_LOGIC_VECTOR ( 23 downto 0 );
    mode : in STD_LOGIC;
    q_max : in STD_LOGIC_VECTOR ( 23 downto 0 )
  );
  end component PID_dpwm_chain_x3_dpwm_0_2;
  component PID_dpwm_chain_x3_xlslice_0_0 is
  port (
    Din : in STD_LOGIC_VECTOR ( 31 downto 0 );
    Dout : out STD_LOGIC_VECTOR ( 23 downto 0 )
  );
  end component PID_dpwm_chain_x3_xlslice_0_0;
  component PID_dpwm_chain_x3_xlslice_0_1 is
  port (
    Din : in STD_LOGIC_VECTOR ( 31 downto 0 );
    Dout : out STD_LOGIC_VECTOR ( 23 downto 0 )
  );
  end component PID_dpwm_chain_x3_xlslice_0_1;
  component PID_dpwm_chain_x3_xlslice_0_2 is
  port (
    Din : in STD_LOGIC_VECTOR ( 31 downto 0 );
    Dout : out STD_LOGIC_VECTOR ( 23 downto 0 )
  );
  end component PID_dpwm_chain_x3_xlslice_0_2;
  signal PID_0_y : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PID_1_y : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal PID_2_y : STD_LOGIC_VECTOR ( 31 downto 0 );
  signal xlslice_0_Dout : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal xlslice_1_Dout : STD_LOGIC_VECTOR ( 23 downto 0 );
  signal xlslice_2_Dout : STD_LOGIC_VECTOR ( 23 downto 0 );
  attribute X_INTERFACE_INFO : string;
  attribute X_INTERFACE_INFO of clk_0 : signal is "xilinx.com:signal:clock:1.0 CLK.CLK_0 CLK";
  attribute X_INTERFACE_PARAMETER : string;
  attribute X_INTERFACE_PARAMETER of clk_0 : signal is "XIL_INTERFACENAME CLK.CLK_0, CLK_DOMAIN PID_dpwm_chain_x3_clk_0, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0";
begin
PID_0: component PID_dpwm_chain_x3_PID_0_0
     port map (
      C1(31 downto 0) => C1_0(31 downto 0),
      C2(31 downto 0) => C2_0(31 downto 0),
      clk => clk_0,
      en => en_0,
      kiTc(31 downto 0) => kiTc_0(31 downto 0),
      kp(31 downto 0) => kp_0(31 downto 0),
      res => res_0,
      sample_pulse => sample_pulse_0,
      x(31 downto 0) => x_0(31 downto 0),
      x_ref(31 downto 0) => x_ref_0(31 downto 0),
      y(31 downto 0) => PID_0_y(31 downto 0),
      y_max(31 downto 0) => y_max_0(31 downto 0),
      y_min(31 downto 0) => y_min_0(31 downto 0)
    );
PID_1: component PID_dpwm_chain_x3_PID_0_1
     port map (
      C1(31 downto 0) => C1_1(31 downto 0),
      C2(31 downto 0) => C2_1(31 downto 0),
      clk => clk_0,
      en => en_1,
      kiTc(31 downto 0) => kiTc_1(31 downto 0),
      kp(31 downto 0) => kp_1(31 downto 0),
      res => res_1,
      sample_pulse => sample_pulse_1,
      x(31 downto 0) => x_1(31 downto 0),
      x_ref(31 downto 0) => x_ref_1(31 downto 0),
      y(31 downto 0) => PID_1_y(31 downto 0),
      y_max(31 downto 0) => y_max_1(31 downto 0),
      y_min(31 downto 0) => y_min_1(31 downto 0)
    );
PID_2: component PID_dpwm_chain_x3_PID_0_2
     port map (
      C1(31 downto 0) => C1_2(31 downto 0),
      C2(31 downto 0) => C2_2(31 downto 0),
      clk => clk_0,
      en => en_2,
      kiTc(31 downto 0) => kiTc_2(31 downto 0),
      kp(31 downto 0) => kp_2(31 downto 0),
      res => res_2,
      sample_pulse => sample_pulse_2,
      x(31 downto 0) => x_2(31 downto 0),
      x_ref(31 downto 0) => x_ref_2(31 downto 0),
      y(31 downto 0) => PID_2_y(31 downto 0),
      y_max(31 downto 0) => y_max_2(31 downto 0),
      y_min(31 downto 0) => y_min_2(31 downto 0)
    );
dpwm_0: component PID_dpwm_chain_x3_dpwm_0_0
     port map (
      clk => clk_0,
      duty(23 downto 0) => xlslice_0_Dout(23 downto 0),
      en => en_0,
      mode => mode_0,
      pwm => pwm_0,
      q_max(23 downto 0) => q_max_0(23 downto 0),
      res => res_0
    );
dpwm_1: component PID_dpwm_chain_x3_dpwm_0_1
     port map (
      clk => clk_0,
      duty(23 downto 0) => xlslice_1_Dout(23 downto 0),
      en => en_1,
      mode => mode_1,
      pwm => pwm_1,
      q_max(23 downto 0) => q_max_1(23 downto 0),
      res => res_1
    );
dpwm_2: component PID_dpwm_chain_x3_dpwm_0_2
     port map (
      clk => clk_0,
      duty(23 downto 0) => xlslice_2_Dout(23 downto 0),
      en => en_2,
      mode => mode_2,
      pwm => pwm_2,
      q_max(23 downto 0) => q_max_2(23 downto 0),
      res => res_2
    );
xlslice_0: component PID_dpwm_chain_x3_xlslice_0_0
     port map (
      Din(31 downto 0) => PID_0_y(31 downto 0),
      Dout(23 downto 0) => xlslice_0_Dout(23 downto 0)
    );
xlslice_1: component PID_dpwm_chain_x3_xlslice_0_1
     port map (
      Din(31 downto 0) => PID_1_y(31 downto 0),
      Dout(23 downto 0) => xlslice_1_Dout(23 downto 0)
    );
xlslice_2: component PID_dpwm_chain_x3_xlslice_0_2
     port map (
      Din(31 downto 0) => PID_2_y(31 downto 0),
      Dout(23 downto 0) => xlslice_2_Dout(23 downto 0)
    );
end STRUCTURE;
